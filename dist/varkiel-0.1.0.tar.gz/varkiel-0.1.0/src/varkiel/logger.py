import logging

class ReflectiveLogger:
    def __init__(self):
        self.logger = logging.getLogger('reflective')
        self.logger.setLevel(logging.INFO)
        handler = logging.FileHandler('reflective.log')
        formatter = logging.Formatter('%(asctime)s - %(message)s')
        handler.setFormatter(formatter)
        self.logger.addHandler(handler)
        
    def log_decision(self, decision_data):
        self.logger.info(decision_data)
